# adalet
adalet denemesi
